import React, { useEffect, useState } from 'react';
import styles from './Dashboard.module.css';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Legend,

} from 'recharts';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import { Button } from 'reactstrap';
import { Progress } from 'reactstrap';
import 'react-circular-progressbar/dist/styles.css';
import Modal from 'react-modal';
import {
  getEmployeeDashboard,
  getAllTasks,
  getAllProjects,
  getLeaveRequestsByEmployeeId,
  markTaskAsCompleted
} from '../../Services/Services';


const COLORS = ['#00C49F', '#FF8042', '#0088FE', '#FFBB28'];

const PriorityBadge = ({ priority }) => {
  let className = styles.priorityBadge;
  
  switch (priority?.toLowerCase()) {
    case 'high':
      className += ` ${styles.highPriority}`;
      break;
    case 'medium':
      className += ` ${styles.mediumPriority}`;
      break;
    case 'low':
      className += ` ${styles.lowPriority}`;
      break;
    default:
      break;
  }
  
  return <span className={className}>{priority}</span>;
};

const Dashboard = () => {
  const [stats, setStats] = useState({
    present: 0,
    absent: 0,
    wfh: 0,
    tasks: 0,
  });
  
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [performanceData, setPerformanceData] = useState([]);
  
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        setError(null);

        console.log('Fetching dashboard data...');
        const dashboardResponse = await getEmployeeDashboard();
        console.log('Dashboard response:', dashboardResponse.data);

        console.log('Fetching tasks...');
        const tasksResponse = await getAllTasks();
        console.log('Tasks response:', tasksResponse.data);
        setTasks(tasksResponse.data);

        console.log('Fetching projects...');
        const projectsResponse = await getAllProjects();
        console.log('Projects response:', projectsResponse.data);
        setProjects(projectsResponse.data);

        console.log('Fetching leave requests...');

        const leaveResponse = await getLeaveRequestsByEmployeeId(1);
        console.log('Leave requests response:', leaveResponse.data);
        setLeaveRequests(leaveResponse.data);

        const processedPerformanceData = processPerformanceData(tasksResponse.data);
        setPerformanceData(processedPerformanceData);

        setStats({
          present: dashboardResponse.data?.present || 0,
          absent: dashboardResponse.data?.absent || 0,
          wfh: dashboardResponse.data?.wfh || 0,
          tasks: tasksResponse.data?.length || 0,
        });

        setLoading(false);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        console.error('Error details:', {
          message: err.message,
          response: err.response?.data,
          status: err.response?.status,
          headers: err.response?.headers
        });
        setError(err.response?.data?.message || err.message || 'Failed to fetch dashboard data');
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const processPerformanceData = (tasks) => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    return months.map(month => {
      const monthTasks = tasks.filter(task => {
        const taskDate = new Date(task.dueDate);
        return taskDate.getMonth() === months.indexOf(month);
      });
      
      return {
        month,
        notStarted: monthTasks.filter(task => !task.completed && !task.progress).length,
        completed: monthTasks.filter(task => task.completed).length,
        pending: monthTasks.filter(task => !task.completed && task.progress).length,
      };
    });
  };

  const completedTasksCount = tasks.filter(task => task.completed).length;
  const pendingTasksCount = tasks.filter(task => !task.completed).length;
  const completedPercentage = (completedTasksCount / tasks.length) * 100 || 0;
  const pendingPercentage = (pendingTasksCount / tasks.length) * 100 || 0;
  const inProgressPercentage = 100 - completedPercentage - pendingPercentage;

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const handleTaskComplete = async (taskId) => {
    try {
      await markTaskAsCompleted(taskId);
      const tasksResponse = await getAllTasks();
      setTasks(tasksResponse.data);
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) {
    return <div className={styles.loading}>Loading...</div>;
  }

  if (error) {
    return <div className={styles.error}>Error: {error}</div>;
  }

  return (
    <div className={styles.dashboardContainer}>
      <div className={styles.sidebarWrapper}>
      </div>

      <div className={styles.main}>
        <header className={styles.header}>Dashboard</header>

        <section className={styles.quickStats}>
          <div className={styles.statCard}>
            <h3>Total Present</h3>
            <p>{stats.present}</p>
          </div>
          <div className={styles.statCard}>
            <h3>Total Absent</h3>
            <p>{stats.absent}</p>
          </div>
          <div className={styles.statCard}>
            <h3>Work from home</h3>
            <p>{stats.wfh}</p>
          </div>
          <div className={styles.statCard}>
            <h3>Total Tasks</h3>
            <p>{stats.tasks}</p>
          </div>
        </section>

        <section className={styles.graphSection}>
          <div className={styles.chartContainer}>
            <h3>Task Completion Status</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [`${value} tasks`, name.replace(/([A-Z])/g, ' $1').trim()]}
                  labelFormatter={(label) => `Month: ${label}`}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="notStarted"
                  name="Not Started"
                  stroke="#8884d8"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="completed"
                  name="Completed"
                  stroke="#00C49F"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="pending"
                  name="Pending"
                  stroke="#FF8042"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className={styles.chartContainer}>
            <h3>Project Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={projects.map(project => ({
                    name: project.name,
                    value: project.tasks?.length || 0
                  }))}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {projects.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `${value} tasks`} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </section>
        <section className={styles.tasksSection}>
          <div className={styles.taskProgressContainer}>
            <h3>Task Status</h3>
            <div className={styles.circularProgressWrapper}>
              <CircularProgressbar
                value={completedPercentage}
                text={`${Math.round(completedPercentage)}%`}
                styles={buildStyles({
                  pathColor: '#00C49F',
                  textColor: '#333',
                  trailColor: '#f4f4f4',
                })}
                className={styles.circularProgress}
              />
            </div>
            
            <div className={styles.taskStatusContainer}>
              <div className={styles.progressBarContainer}>
                <p>Completed Tasks ({completedTasksCount})</p>
                <Progress value={completedPercentage} color="success" />
              </div>
              <div className={styles.progressBarContainer}>
                <p>In Progress Tasks ({Math.round(stats.tasks - completedTasksCount - pendingTasksCount)})</p>
                <Progress value={inProgressPercentage} color="warning" />
              </div>
              <div className={styles.progressBarContainer}>
                <p>Pending Tasks ({pendingTasksCount})</p>
                <Progress value={pendingPercentage} color="danger" />
              </div>
            </div>
          </div>

          <div className={styles.upcomingTasksContainer}>
            <h3>Upcoming Tasks</h3>
            <div className={styles.tasksList}>
              {tasks.map(task => (
                <div 
                  key={task.id} 
                  className={styles.taskCard}
                  onClick={() => {
                    setSelectedTask(task);
                    setModalOpen(true);
                  }}
                >
                  <div className={styles.taskHeader}>
                    <h4>{task.title}</h4>
                    <PriorityBadge priority={task.priority} />
                  </div>
                  <div className={styles.taskDetails}>
                    <span className={styles.taskDeadline}>Due: {formatDate(task.dueDate)}</span>
                    <span className={styles.taskAssignee}>{task.assignedTo}</span>
                  </div>
                  <div className={styles.clickHint}>
                    <span>Click for details</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Modal
          isOpen={modalOpen}
          onRequestClose={() => setModalOpen(false)}
          className={styles.taskDetailModal}
          overlayClassName={styles.modalOverlay}
          ariaHideApp={false}
          contentLabel="Task Details"
        >
          {selectedTask && (
            <div className={styles.modalContainer}>
              <div className={styles.modalHeader}>
                <h3>{selectedTask.title}</h3>
                <PriorityBadge priority={selectedTask.priority} />
                <button 
                  className={styles.closeButton}
                  onClick={() => setModalOpen(false)}
                >
                  &times;
                </button>
              </div>
              
              <div className={styles.modalContent}>
                <div className={styles.modalRow}>
                  <div className={styles.modalLabel}>Assignee:</div>
                  <div>{selectedTask.assignedTo}</div>
                </div>
                <div className={styles.modalRow}>
                  <div className={styles.modalLabel}>Deadline:</div>
                  <div>{formatDate(selectedTask.dueDate)}</div>
                </div>
                <div className={styles.modalRow}>
                  <div className={styles.modalLabel}>Status:</div>
                  <div className={`${styles.statusBadge} ${styles[selectedTask.completed ? 'completed' : 'pending']}`}>
                    {selectedTask.completed ? 'Completed' : 'Pending'}
                  </div>
                </div>
                <div className={styles.modalRow}>
                  <div className={styles.modalLabel}>Description:</div>
                  <div className={styles.modalDescription}>{selectedTask.description}</div>
                </div>
              </div>
              
              <div className={styles.modalFooter}>
                {/* {!selectedTask.completed && (
                  <Button 
                    color="success"
                    onClick={() => handleTaskComplete(selectedTask.id)}
                    className={styles.primaryButton}
                  >
                    Mark as Completed
                  </Button>
                )} */}
                <Button 
                  color="secondary"
                  onClick={() => setModalOpen(false)}
                  className={styles.primaryButton}
                  style={{ marginLeft: '10px' }}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </Modal>
         <footer className="footer">
                <div className="footerLeft">
                Copyright © 2025 Kodvix Technologies. All Rights Reserved.
              </div>
            <div className="footer-right">
                <a
                  href="https://www.kodvix.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Kodvix Technologies
                </a>
              </div>
            </footer> 
      </div>
       
    </div>
  );
};

export default Dashboard;

