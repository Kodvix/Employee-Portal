// import {  Routes, Route } from 'react-router-dom';
// import './styles/index.css'; 

// // User Imports 
// import EmployeeDashboard from './Pages/EmployeeDashboard'
// import Dashboard from './Pages/User/Dashboard.jsx';
// import AttendanceOverview from './Pages/User/AttendanceOverview.jsx';
// import Task from './Pages/User/EmployeeTask.jsx';
// import LeaveRequestPage from './Pages/User/HRRequestPage.jsx';
// import UserPerformances from './Pages/User/UserPerformances.jsx';
// import OfficeEventPage from './Pages/User/OfficeEventPage.jsx';
// import DocumentCenter from './Pages/User/DocumentCenter.jsx';
// // Admin imports
// import AdminDashboards from './Pages/AdminDashboards.jsx';
// import AdminDashboard from './Pages/Admin/AdminDashboard.jsx';
// import AdminEmployeeManagement from './Pages/Admin/AdminEmployeeManagement.jsx';
// import AdminAttendancePage from './Pages/Admin/AdminAttendancePage.jsx';
// import AdminTask from './Pages/Admin/AdminTask.jsx';
// import AdminHRManagementPage from './Pages/Admin/AdminHRManagementPage.jsx';
// import AddOfficeEventPage from './Pages/Admin/AddOfficeEventPage.jsx';
// import AdminDocumentsPage from './Pages/Admin/AdminDocumentsPage.jsx';
// // Auth imports 
// import EMSLoginPage from './Pages/Login/EMSLoginPage.jsx';
// import ForgotPassword from './Pages/ForgotPassword/ForgotPassword.jsx';
// // import NotificationBell from './components/NotificationBell.jsx/NotificationBell.jsx'; 
// import EmployeeProfile from './Pages/User/EmployeeProfile.jsx';
// import NotFoundPage from './Pages/ErrorPages/NotFoundPage.jsx';

// function App() {
//   return (
   
//       <Routes>
         
//         <Route path="/" element={<EMSLoginPage />} />
//         <Route path="/forgot-password" element={<ForgotPassword />} />
//         <Route path="*" element={<NotFoundPage />} />


//         <Route path="/employee-dashboard" element={  <EmployeeDashboard />} >
//         <Route index element={<Dashboard />} /> 
//         <Route path="Attendance" element={<AttendanceOverview />} />
//         <Route path="Task" element={<Task/>} />
//         <Route path="LeaveRequestPage" element={<LeaveRequestPage />} />
//         <Route path="UserPerformances" element={<UserPerformances/>} />
//         {/* <Route path="NotificationBell" element={<NotificationBell />} /> */}
//         <Route path="DocumentCenter" element={<DocumentCenter />} />
//         <Route path="OfficeEventPage" element={<OfficeEventPage />} />
//         <Route path="EmployeeProfile" element={<EmployeeProfile />} />

//         </Route>
      
//       {/* Admin */}
//       <Route path="/Admin-dashboard" element={ <AdminDashboards />} >
//       <Route index element={<AdminDashboard />} />
//       <Route path="AdminEmployeeManagement" element={<AdminEmployeeManagement />} />
//       <Route path="AdminAttendancePage" element={<AdminAttendancePage />} />
//       <Route path="AdminTask" element={<AdminTask />} />
//       <Route path="AdminHRManagementPage" element={<AdminHRManagementPage />} />
//       <Route path="AddOfficeEventPage" element={<AddOfficeEventPage />} />
//       <Route path="AdminDocumentsPage" element={<AdminDocumentsPage />} />

//       </Route>
     
//       </Routes>
//   );
// }

// export default App;


import { Routes, Route } from 'react-router-dom';
import './styles/index.css'; 

// User Imports 
import EmployeeDashboard from './Pages/EmployeeDashboard'
import Dashboard from './Pages/User/Dashboard.jsx';
import AttendanceOverview from './Pages/User/AttendanceOverview.jsx';
import Task from './Pages/User/EmployeeTask.jsx';
import LeaveRequestPage from './Pages/User/HRRequestPage.jsx';
import UserPerformances from './Pages/User/UserPerformances.jsx';
import OfficeEventPage from './Pages/User/OfficeEventPage.jsx';
import DocumentCenter from './Pages/User/DocumentCenter.jsx';

// Admin imports
import AdminDashboards from './Pages/AdminDashboards.jsx';
import AdminDashboard from './Pages/Admin/AdminDashboard.jsx';
import AdminEmployeeManagement from './Pages/Admin/AdminEmployeeManagement.jsx';
import AdminAttendancePage from './Pages/Admin/AdminAttendancePage.jsx';
import AdminTask from './Pages/Admin/AdminTask.jsx';
import AdminHRManagementPage from './Pages/Admin/AdminHRManagementPage.jsx';
import AddOfficeEventPage from './Pages/Admin/AddOfficeEventPage.jsx';
import AdminDocumentsPage from './Pages/Admin/AdminDocumentsPage.jsx';

// Auth imports 
import EMSLoginPage from './Pages/Login/EMSLoginPage.jsx';
import ForgotPassword from './Pages/ForgotPassword/ForgotPassword.jsx';
import EmployeeProfile from './Pages/User/EmployeeProfile.jsx';
import NotFoundPage from './Pages/ErrorPages/NotFoundPage.jsx';

// Protected Route Components
import { 
  GuestRoute, 
  EmployeeProtectedRoute, 
  AdminProtectedRoute 
} from './components/ProtectedRoutes.jsx'; // Adjust path as needed

function App() {
  return (
    <Routes>
      {/* Guest Routes - Only accessible when not authenticated */}
      <Route 
        path="/" 
        element={
          <GuestRoute>
            <EMSLoginPage />
          </GuestRoute>
        } 
      />
      <Route 
        path="/forgot-password" 
        element={
          <GuestRoute>
            <ForgotPassword />
          </GuestRoute>
        } 
      />

      {/* Employee Protected Routes */}
      <Route 
        path="/employee-dashboard" 
        element={
          <EmployeeProtectedRoute>
            <EmployeeDashboard />
          </EmployeeProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} /> 
        <Route path="Attendance" element={<AttendanceOverview />} />
        <Route path="Task" element={<Task/>} />
        <Route path="LeaveRequestPage" element={<LeaveRequestPage />} />
        <Route path="UserPerformances" element={<UserPerformances/>} />
        <Route path="DocumentCenter" element={<DocumentCenter />} />
        <Route path="OfficeEventPage" element={<OfficeEventPage />} />
        <Route path="EmployeeProfile" element={<EmployeeProfile />} />
      </Route>
      
      {/* Admin Protected Routes */}
      <Route 
        path="/Admin-dashboard" 
        element={
          <AdminProtectedRoute>
            <AdminDashboards />
          </AdminProtectedRoute>
        }
      >
        <Route index element={<AdminDashboard />} />
        <Route path="AdminEmployeeManagement" element={<AdminEmployeeManagement />} />
        <Route path="AdminAttendancePage" element={<AdminAttendancePage />} />
        <Route path="AdminTask" element={<AdminTask />} />
        <Route path="AdminHRManagementPage" element={<AdminHRManagementPage />} />
        <Route path="AddOfficeEventPage" element={<AddOfficeEventPage />} />
        <Route path="AdminDocumentsPage" element={<AdminDocumentsPage />} />
      </Route>

      {/* 404 Page - Should be last */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

export default App;