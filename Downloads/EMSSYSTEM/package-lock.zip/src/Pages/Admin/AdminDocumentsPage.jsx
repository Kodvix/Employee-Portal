import React, { useState, useEffect } from 'react';
import styles from './AdminDocumentsPage.module.css';
import axios from 'axios';
import { FaFilePdf, FaFileWord, FaFileImage } from 'react-icons/fa';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AdminDocumentsPage = () => {
  const [uploadFiles, setUploadFiles] = useState({});

  const [documents, setDocuments] = useState([]);
  const [filters, setFilters] = useState({ search: '', type: '', docType: '' });
  const [previewDoc, setPreviewDoc] = useState(null);
  const [openEmployee, setOpenEmployee] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [companyDocType, setCompanyDocType] = useState("offerLetterDoc");
  const [uploadingFile, setUploadingFile] = useState(null);

  useEffect(() => {
    fetchAllDocuments();
  }, []);

  const fetchAllDocuments = async () => {
    try {
      setLoading(true);
      console.log('Fetching all documents...');
      
      const [personalDocsRes, companyDocsRes] = await Promise.all([
        axios.get('http://localhost:8080/api/documents/employee/1'),
        axios.get('http://localhost:8080/api/employee-images')
      ]);

      console.log('Personal docs response:', personalDocsRes.data);
      console.log('Company docs response:', companyDocsRes.data);

      // Process personal documents
      const personalDocs = personalDocsRes.data.map(doc => {
        try {
          return {
            id: doc.id,
            empId: doc.employeeId,
            title: doc.name || 'Untitled Document',
            type: getFileType(doc.type || 'application/pdf'),
            uploadDate: doc.uploadDate ? new Date(doc.uploadDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
            fileUrl: doc.data ? `data:${doc.type || 'application/pdf'};base64,${doc.data}` : null,
            docType: 'personal',
            employeeName: doc.employeeName || `Employee ${doc.employeeId}`
          };
        } catch (err) {
          console.error('Error processing personal document:', doc, err);
          return null;
        }
      }).filter(doc => doc !== null);

      // Process company documents
      const companyDocs = companyDocsRes.data.flatMap(doc => {
        const docs = [];
        try {
          if (doc.offerLetterDoc) {
            docs.push({
              id: doc.id,
              empId: doc.empId,
              title: 'Offer Letter',
              type: 'PDF',
              uploadDate: new Date().toISOString().split('T')[0],
              fileUrl: `data:application/pdf;base64,${doc.offerLetterDoc}`,
              docType: 'company',
              companyDocType: 'offerLetterDoc',
              employeeName: doc.employeeName || `Employee ${doc.empId}`
            });
          }
          if (doc.latestPaySlipDoc) {
            docs.push({
              id: doc.id,
              empId: doc.empId,
              title: 'Latest Payslip',
              type: 'PDF',
              uploadDate: new Date().toISOString().split('T')[0],
              fileUrl: `data:application/pdf;base64,${doc.latestPaySlipDoc}`,
              docType: 'company',
              companyDocType: 'latestPaySlipDoc',
              employeeName: doc.employeeName || `Employee ${doc.empId}`
            });
          }
          if (doc.doc) {
            docs.push({
              id: doc.id,
              empId: doc.empId,
              title: 'Additional Document',
              type: 'PDF',
              uploadDate: new Date().toISOString().split('T')[0],
              fileUrl: `data:application/pdf;base64,${doc.doc}`,
              docType: 'company',
              companyDocType: 'doc',
              employeeName: doc.employeeName || `Employee ${doc.empId}`
            });
          }
        } catch (err) {
          console.error('Error processing company document:', doc, err);
        }
        return docs;
      });

      const allDocs = [...personalDocs, ...companyDocs];
      console.log('All processed documents:', allDocs);
      setDocuments(allDocs);
      setError(null);
    } catch (err) {
      console.error('Error fetching documents:', err);
      if (err.response) {
        console.error('Error response:', err.response.data);
        console.error('Error status:', err.response.status);
      }
      setError('Failed to fetch documents. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const getFileType = (mimeType) => {
    if (mimeType.includes('pdf')) return 'PDF';
    if (mimeType.includes('word')) return 'Word';
    if (mimeType.includes('image')) return 'Image';
    return 'Other';
  };

  const getFileIcon = (type) => {
    switch (type) {
      case 'PDF':
        return <FaFilePdf />;
      case 'Word':
        return <FaFileWord />;
      case 'Image':
        return <FaFileImage />;
      default:
        return <FaFilePdf />;
    }
  };

  const handleEmployeeClick = (empId) => {
    setOpenEmployee(empId);
  };

  const handleFileChange = (e) => {
    setUploadingFile(e.target.files[0]);
  };
  const handleUploadFileChange = (e, type) => {
  setUploadFiles(prev => ({ ...prev, [type]: e.target.files[0] }));
};



const handleUpload = async (docType) => {
  const file = uploadFiles[docType];
  if (!file || !openEmployee) return;

  try {
    const companyFormData = new FormData();
    companyFormData.append("empId", openEmployee);
    companyFormData.append(docType, file);

    const response = await axios.post(
      `http://localhost:8080/api/employee-images`,
      companyFormData,
      {
        headers: {
          "Content-Type": "multipart/form-data"
        },
      }
    );

    toast.success(`${docType} uploaded successfully!`);
    setUploadFiles(prev => ({ ...prev, [docType]: null }));
    fetchAllDocuments();
  } catch (err) {
    console.error("Upload failed:", err);
    toast.error("Failed to upload " + docType);
  }
};

    

  const handleDelete = async (docId, docType) => {
    try {
      if (docType === 'company') {
        await axios.delete(`http://localhost:8080/api/employee-images/${docId}`);
        toast.success("Company document deleted successfully!");
      } else {
        await axios.delete(`http://localhost:8080/api/documents/${docId}`);
        toast.success("Personal document deleted successfully!");
      }
      fetchAllDocuments();
    } catch (err) {
      console.error("Delete failed:", err);
      if (err.response) {
        console.error('Error response:', err.response.data);
        console.error('Error status:', err.response.status);
      }
      toast.error("Failed to delete document ❌");
    }
  };

  const filteredDocs = documents.filter(doc => {
    const matchesSearch =
      doc.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      `Emp ID: ${doc.empId}`.toLowerCase().includes(filters.search.toLowerCase()) ||
      doc.docType.toLowerCase().includes(filters.docType.toLowerCase());
    const matchesType = !filters.type || doc.type === filters.type;
    return matchesSearch && matchesType;
  });

  const groupByEmployee = docs => {
    return docs.reduce((acc, doc) => {
      if (!acc[doc.empId]) acc[doc.empId] = [];
      acc[doc.empId].push(doc);
      return acc;
    }, {});
  };

  const groupedDocs = groupByEmployee(filteredDocs);

  const refreshDocuments = () => {
    fetchAllDocuments();
  };

  useEffect(() => {
    fetchAllDocuments();
    const interval = setInterval(fetchAllDocuments, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return <div className={styles.loading}>Loading documents...</div>;
  if (error) return <div className={styles.error}>{error}</div>;

  return (
    <div className={styles.container}>
      <div className={styles.main}>
        <div className={styles.head}>
          <header className={styles.header}>
            <h2>📁 Admin Document Center</h2>
          </header>

          <div className={styles.filterBar}>
            <input
              type="text"
              placeholder="🔍 Search by name, employee ID, or document type..."
              value={filters.search}
              onChange={e => setFilters({ ...filters, search: e.target.value })}
            />
            <select
              value={filters.type}
              onChange={e => setFilters({ ...filters, type: e.target.value })}
            >
              <option value="">All Types</option>
              <option value="PDF">PDF</option>
              <option value="Word">Word</option>
              <option value="Image">Image</option>
            </select>
            <select
              value={filters.docType}
              onChange={e => setFilters({ ...filters, docType: e.target.value })}
            >
              <option value="">All Categories</option>
              <option value="personal">Personal Documents</option>
              <option value="company">Company Documents</option>
            </select>
          </div>
        </div>

        {!openEmployee ? (
          <div className={styles.folderGrid}>
            {Object.keys(groupedDocs).length === 0 ? (
              <p className={styles.noResults}>No documents match your filters.</p>
            ) : (
              Object.entries(groupedDocs).map(([empId, docs]) => (
                <div key={empId} className={styles.folderCard} onClick={() => handleEmployeeClick(empId)}>
                  <div className={styles.folderIcon}>📂</div>
                  <p>Emp ID: {empId}</p>
                  <p>{docs.length} documents</p>
                  <p className={styles.employeeName}>{docs[0]?.employeeName || `Employee ${empId}`}</p>
                </div>
              ))
            )}
          </div>
        ) : (
          <div className={styles.employeeDocs}>
            <div className={styles.employeeHeader}>
              <h3>📁 Documents for {documents.find(d => d.empId === openEmployee)?.employeeName || `Employee ${openEmployee}`}</h3>
              <button onClick={() => setOpenEmployee(null)}>⬅ Back to Folders</button>
            </div>

          
<div className={styles.uploadSection}>
  {/* Upload Offer Letter */}
  <div className={styles.uploadControls}>
    <label>📄 Upload Offer Letter:</label>
    <input type="file" onChange={(e) => handleUploadFileChange(e, 'offerLetterDoc')} />
    
  </div>

  {/* Upload Latest Payslip */}
  <div className={styles.uploadControls}>
    <label>📄 Upload Latest Payslip:</label>
    <input type="file" onChange={(e) => handleUploadFileChange(e, 'latestPaySlipDoc')} />
    
  </div>

  {/* Upload Additional Document */}
  <div className={styles.uploadControls}>
    <label>📄 Upload Additional Document:</label>
    <input type="file" onChange={(e) => handleUploadFileChange(e, 'doc')} />
    
  </div>
  <button onClick={() => handleUpload('offerLetterDoc')}>⬆ Upload Offer Letter</button>
</div>

            <div className={styles.grid}>
              {filteredDocs
                .filter(doc => doc.empId === openEmployee)
                .map(doc => (
                  <div key={doc.id} className={styles.card}>
                    <div className={styles.icon}>{getFileIcon(doc.type)}</div>
                    <div className={styles.cardContent}>
                      <h4>{doc.title}</h4>
                      <p><strong>Type:</strong> {doc.type}</p>
                      <p><strong>Date:</strong> {doc.uploadDate}</p>
                      <p><strong>Category:</strong> {doc.docType === 'personal' ? 'Personal' : 'Company'}</p>
                      {doc.companyDocType && <p><strong>Document Type:</strong> {doc.companyDocType}</p>}
                    </div>
                    <div className={styles.cardActions}>
                      <button onClick={() => window.open(doc.fileUrl, '_blank')}>👁 View</button>
                      <button onClick={() => handleDelete(doc.id, doc.docType)}>🗑 Delete</button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
     <footer className={styles.footer}>
        <div className={styles.footerLeft}>
        Copyright © 2025 Kodvix Technologies. All Rights Reserved.
      </div>
    <div className={styles.footerright}>
        <a
          href="https://www.kodvix.com/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Kodvix Technologies
        </a>
      </div>
    </footer>
      </div>
    </div>
  );
};


export default AdminDocumentsPage;
