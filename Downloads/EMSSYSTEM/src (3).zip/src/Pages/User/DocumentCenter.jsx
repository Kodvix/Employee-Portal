import React, { useState, useEffect } from "react";
import axios from "axios";
import styles from "./DocumentCenter.module.css";
import { FaFilePdf, FaFileWord, FaFileImage } from "react-icons/fa";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { useAuth } from '../../context/AuthContext'; // Import useAuth hook
import { useNavigate } from 'react-router-dom'; // Import useNavigate for redirects

const API_BASE_URL = 'http://localhost:8080/api';

const DocumentCenter = () => {
  const { employeeId, isAuthenticated, logout } = useAuth();
    const navigate = useNavigate();
    
  const [personalDocs, setPersonalDocs] = useState([]);
  const [companyDocs, setCompanyDocs] = useState([]);
  const [search, setSearch] = useState("");
  const [uploadingFile, setUploadingFile] = useState(null);
  const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
 useEffect(() => {
    if (!isAuthenticated || !employeeId) {
      console.error('User not authenticated or employee ID missing');
      navigate('/'); // Redirect to login page
      return;
    }
  }, [isAuthenticated, employeeId, navigate]);

  const fetchEmployeeData = async () => {
    if (!employeeId) {
      console.log('Employee ID not available');
      return;
    }

    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE_URL}/employee/${employeeId}`);
      
    
    } catch (err) {
      console.error("Failed to fetch employee data:", err);
     
      
      // Handle 401 errors specifically
      if (err.response && err.response.status === 401) {
        setError('Authentication failed. Please login again.');
        logout();
        navigate('/');
      }
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchEmployeeDocuments();
    fetchCompanyDocuments();
    
    // Refresh every 30 seconds
    const interval = setInterval(() => {
      fetchEmployeeDocuments();
      fetchCompanyDocuments();
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const fetchEmployeeDocuments = async () => {
    try {
      console.log('Fetching personal documents for employee:', employeeId);
      const res = await axios.get(`${API_BASE_URL}/documents/employee/${employeeId}`);
      console.log('Personal documents response:', res.data);

      if (!Array.isArray(res.data)) {
        console.error('Invalid response format:', res.data);
        toast.error('Invalid response format from server');
        return;
      }

      const docs = res.data.map(doc => {
        try {
          return {
            name: doc.name || 'Untitled Document',
            file: doc.type || 'application/pdf',
            date: doc.uploadDate ? new Date(doc.uploadDate).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
            type: getFileType(doc.type || 'application/pdf'),
            status: "Approved",
            docId: doc.id,
            base64Doc: doc.data
          };
        } catch (err) {
          console.error('Error processing document:', doc, err);
          return null;
        }
      }).filter(doc => doc !== null);

      console.log('Processed personal documents:', docs);
      setPersonalDocs(docs);
    } catch (err) {
      console.error("Failed to fetch personal documents:", err);
      if (err.response) {
        console.error('Error response:', err.response.data);
        console.error('Error status:', err.response.status);
        toast.error(`Failed to fetch personal documents: ${err.response.data?.message || 'Server error'}`);
      } else if (err.request) {
        console.error('No response received:', err.request);
        toast.error('No response from server. Please check your connection.');
      } else {
        console.error('Error setting up request:', err.message);
        toast.error('Failed to fetch personal documents: ' + err.message);
      }
      setPersonalDocs([]);
    }
  };

  const fetchCompanyDocuments = async () => {
    try {
      const res = await axios.get(`${API_BASE_URL}/employee-images/emp/${employeeId}`);
      const docs = [];
      
      res.data.forEach(doc => {
        if (doc.offerLetterDoc) {
          docs.push({
            name: "Offer Letter",
            type: "PDF",
            date: new Date().toISOString().slice(0, 10),
            status: "Approved",
            docId: doc.id,
            base64Doc: doc.offerLetterDoc,
            docType: "offerLetterDoc"
          });
        }
        if (doc.latestPaySlipDoc) {
          docs.push({
            name: "Latest Payslip",
            type: "PDF",
            date: new Date().toISOString().slice(0, 10),
            status: "Approved",
            docId: doc.id,
            base64Doc: doc.latestPaySlipDoc,
            docType: "latestPaySlipDoc"
          });
        }
        if (doc.doc) {
          docs.push({
            name: "Additional Document",
            type: "PDF",
            date: new Date().toISOString().slice(0, 10),
            status: "Approved",
            docId: doc.id,
            base64Doc: doc.doc,
            docType: "doc"
          });
        }
      });
      
      setCompanyDocs(docs);
    } catch (err) {
      console.error("Failed to fetch company documents:", err);
      toast.error("Failed to fetch company documents");
    }
  };

  const getFileType = (mimeType) => {
    if (mimeType.includes('pdf')) return 'PDF';
    if (mimeType.includes('word')) return 'Word';
    if (mimeType.includes('image')) return 'Image';
    return 'Other';
  };

  const getFileIcon = (type) => {
    switch (type) {
      case 'PDF':
        return <FaFilePdf />;
      case 'Word':
        return <FaFileWord />;
      case 'Image':
        return <FaFileImage />;
      default:
        return <FaFilePdf />;
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('File size must be less than 10MB');
      return;
    }

    // Validate file type
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Invalid file type. Please upload PDF, JPEG, PNG, or Word documents only.');
      return;
    }

    setUploadingFile(file);
  };

  const handleUpload = async () => {
    if (!uploadingFile) {
      toast.error('Please select a file to upload');
      return;
    }

    try {
      const formData = new FormData();
      formData.append("file", uploadingFile);
      formData.append("employeeId", employeeId);

      console.log('Uploading personal document:');
      console.log('employeeId:', employeeId);
      console.log('file:', uploadingFile);

      const response = await axios.post(
        `http://localhost:8080/api/documents/upload/${employeeId}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data"
          },
        }
      );

      console.log('Upload response:', response.data);
      toast.success("📁 Personal document uploaded successfully!");
      fetchEmployeeDocuments();
      setUploadingFile(null);
    } catch (err) {
      console.error("Upload failed:", err);
      if (err.response) {
        console.error('Error response:', err.response.data);
        console.error('Error status:', err.response.status);
        console.error('Error headers:', err.response.headers);
        
        const errorMessage = err.response.data?.message || err.response.data || 'Failed to upload document';
        toast.error(`Upload failed: ${errorMessage}`);
      } else if (err.request) {
        console.error('No response received:', err.request);
        toast.error('No response from server. Please check your connection.');
      } else {
        console.error('Error setting up request:', err.message);
        toast.error('Failed to upload document: ' + err.message);
      }
    }
  };

  const handleView = (base64String) => {
    const blob = base64toBlob(base64String, "application/pdf");
    const blobUrl = URL.createObjectURL(blob);
    window.open(blobUrl, "_blank");
  };

  const base64toBlob = (base64, contentType) => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length).fill().map((_, i) => byteCharacters.charCodeAt(i));
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: contentType });
  };

  const filteredPersonalDocs = personalDocs.filter(doc =>
    doc.name.toLowerCase().includes(search.toLowerCase()) ||
    doc.type.toLowerCase().includes(search.toLowerCase())
  );

  const filteredCompanyDocs = companyDocs.filter(doc =>
    doc.name.toLowerCase().includes(search.toLowerCase()) ||
    doc.type.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className={styles.container}>
      <div className={styles.mainContent}>
        <header className={styles.header}>Document Center</header>
        <ToastContainer position="top-right" autoClose={3000} hideProgressBar />

        <section className={styles.section}>
          <h3>1. Personal Documents</h3>
          <input
            type="text"
            placeholder="🔍 Search by name or type..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={styles.searchBar}
          />

          <table className={styles.table}>
            <thead>
              <tr>
                <th>Document</th>
                <th>Type</th>
                <th>File</th>
                <th>Uploaded On</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredPersonalDocs.map((doc, idx) => (
                <tr key={idx}>
                  <td>{doc.name}</td>
                  <td>{doc.type}</td>
                  <td>{getFileIcon(doc.type)} {doc.type}</td>
                  <td>{doc.date}</td>
                  <td>
                    <span className={`${styles.status} ${styles.approved}`}>Approved</span>
                  </td>
                  <td>
                    <button
                      className={styles.viewBtn}
                      onClick={() => handleView(doc.base64Doc)}
                    >
                      👁 View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className={styles.uploadSection}>
            <div className={styles.uploadControls}>
              <input type="file" onChange={handleFileChange} />
              {uploadingFile && <span className={styles.previewText}>Selected: {uploadingFile.name}</span>}
              <button onClick={handleUpload}>⬆ Upload Personal Document</button>
            </div>
          </div>
        </section>

        <section className={styles.section}>
          <h3>2. Company Documents</h3>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Document</th>
                <th>Type</th>
                <th>File</th>
                <th>Uploaded On</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredCompanyDocs.map((doc, idx) => (
                <tr key={idx}>
                  <td>{doc.name}</td>
                  <td>{doc.type}</td>
                  <td>{getFileIcon(doc.type)} {doc.type}</td>
                  <td>{doc.date}</td>
                  <td>
                    <span className={`${styles.status} ${styles.approved}`}>Approved</span>
                  </td>
                  <td>
                    <button
                      className={styles.viewBtn}
                      onClick={() => handleView(doc.base64Doc)}
                    >
                      👁 View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
        
    </div>
  );
};
{
  <footer className="footer">
                <div className="footerLeft">
                Copyright © 2025 Kodvix Technologies. All Rights Reserved.
              </div>
            <div className="footer-right">
                <a
                  href="https://www.kodvix.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Kodvix Technologies
                </a>
              </div>
            </footer> 
}
export default DocumentCenter;

// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import styles from "./DocumentCenter.module.css";
// import { FaFilePdf, FaFileWord, FaFileImage } from "react-icons/fa";
// import { ToastContainer, toast } from "react-toastify";
// import { useAuth } from "../../context/AuthContext"; // Import auth context
// import 'react-toastify/dist/ReactToastify.css';

// const DocumentCenter = () => {
//   const { employeeId, currentUser, isAuthenticated } = useAuth(); // Get employee ID from context
//   const [personalDocs, setPersonalDocs] = useState([]);
//   const [companyDocs, setCompanyDocs] = useState([]);
//   const [search, setSearch] = useState("");
//   const [uploadingFile, setUploadingFile] = useState(null);

//   // Redirect if not authenticated
//   useEffect(() => {
//     if (!isAuthenticated) {
//       // Handle redirect to login or show error
//       console.error("User not authenticated");
//       return;
//     }
//   }, [isAuthenticated]);

//   useEffect(() => {
//     if (employeeId) {
//       fetchEmployeeDocuments();
//       fetchCompanyDocuments();
      
//       // Refresh every 30 seconds
//       const interval = setInterval(() => {
//         fetchEmployeeDocuments();
//         fetchCompanyDocuments();
//       }, 30000);
      
//       return () => clearInterval(interval);
//     }
//   }, [employeeId]);

//   const fetchEmployeeDocuments = async () => {
//     if (!employeeId) {
//       console.error("No employee ID available");
//       toast.error("Employee ID not found. Please login again.");
//       return;
//     }

//     try {
//       console.log('Fetching personal documents for employee:', employeeId);
//       const res = await axios.get(`http://localhost:8080/api/documents/employee/${employeeId}`);
//       console.log('Personal documents response:', res.data);

//       if (!Array.isArray(res.data)) {
//         console.error('Invalid response format:', res.data);
//         toast.error('Invalid response format from server');
//         return;
//       }

//       const docs = res.data.map(doc => {
//         try {
//           return {
//             name: doc.name || 'Untitled Document',
//             file: doc.type || 'application/pdf',
//             date: doc.uploadDate ? new Date(doc.uploadDate).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
//             type: getFileType(doc.type || 'application/pdf'),
//             status: "Approved",
//             docId: doc.id,
//             base64Doc: doc.data
//           };
//         } catch (err) {
//           console.error('Error processing document:', doc, err);
//           return null;
//         }
//       }).filter(doc => doc !== null);

//       console.log('Processed personal documents:', docs);
//       setPersonalDocs(docs);
//     } catch (err) {
//       console.error("Failed to fetch personal documents:", err);
//       if (err.response) {
//         console.error('Error response:', err.response.data);
//         console.error('Error status:', err.response.status);
//         toast.error(`Failed to fetch personal documents: ${err.response.data?.message || 'Server error'}`);
//       } else if (err.request) {
//         console.error('No response received:', err.request);
//         toast.error('No response from server. Please check your connection.');
//       } else {
//         console.error('Error setting up request:', err.message);
//         toast.error('Failed to fetch personal documents: ' + err.message);
//       }
//       setPersonalDocs([]);
//     }
//   };

//   const fetchCompanyDocuments = async () => {
//     if (!employeeId) {
//       console.error("No employee ID available");
//       return;
//     }

//     try {
//       const res = await axios.get(`http://localhost:8080/api/employee-images/emp/${employeeId}`);
//       const docs = [];
      
//       res.data.forEach(doc => {
//         if (doc.offerLetterDoc) {
//           docs.push({
//             name: "Offer Letter",
//             type: "PDF",
//             date: new Date().toISOString().slice(0, 10),
//             status: "Approved",
//             docId: doc.id,
//             base64Doc: doc.offerLetterDoc,
//             docType: "offerLetterDoc"
//           });
//         }
//         if (doc.latestPaySlipDoc) {
//           docs.push({
//             name: "Latest Payslip",
//             type: "PDF",
//             date: new Date().toISOString().slice(0, 10),
//             status: "Approved",
//             docId: doc.id,
//             base64Doc: doc.latestPaySlipDoc,
//             docType: "latestPaySlipDoc"
//           });
//         }
//         if (doc.doc) {
//           docs.push({
//             name: "Additional Document",
//             type: "PDF",
//             date: new Date().toISOString().slice(0, 10),
//             status: "Approved",
//             docId: doc.id,
//             base64Doc: doc.doc,
//             docType: "doc"
//           });
//         }
//       });
      
//       setCompanyDocs(docs);
//     } catch (err) {
//       console.error("Failed to fetch company documents:", err);
//       toast.error("Failed to fetch company documents");
//     }
//   };

//   const getFileType = (mimeType) => {
//     if (mimeType.includes('pdf')) return 'PDF';
//     if (mimeType.includes('word')) return 'Word';
//     if (mimeType.includes('image')) return 'Image';
//     return 'Other';
//   };

//   const getFileIcon = (type) => {
//     switch (type) {
//       case 'PDF':
//         return <FaFilePdf />;
//       case 'Word':
//         return <FaFileWord />;
//       case 'Image':
//         return <FaFileImage />;
//       default:
//         return <FaFilePdf />;
//     }
//   };

//   const handleFileChange = (e) => {
//     const file = e.target.files[0];
//     if (!file) return;

//     // Validate file size (max 10MB)
//     if (file.size > 10 * 1024 * 1024) {
//       toast.error('File size must be less than 10MB');
//       return;
//     }

//     // Validate file type
//     const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
//     if (!allowedTypes.includes(file.type)) {
//       toast.error('Invalid file type. Please upload PDF, JPEG, PNG, or Word documents only.');
//       return;
//     }

//     setUploadingFile(file);
//   };

//   const handleUpload = async () => {
//     if (!uploadingFile) {
//       toast.error('Please select a file to upload');
//       return;
//     }

//     if (!employeeId) {
//       toast.error('Employee ID not found. Please login again.');
//       return;
//     }

//     try {
//       const formData = new FormData();
//       formData.append("file", uploadingFile);
//       formData.append("employeeId", employeeId);

//       console.log('Uploading personal document:');
//       console.log('employeeId:', employeeId);
//       console.log('file:', uploadingFile);

//       const response = await axios.post(
//         `http://localhost:8080/api/documents/upload/${employeeId}`,
//         formData,
//         {
//           headers: {
//             "Content-Type": "multipart/form-data"
//           },
//         }
//       );

//       console.log('Upload response:', response.data);
//       toast.success("📁 Personal document uploaded successfully!");
//       fetchEmployeeDocuments();
//       setUploadingFile(null);
//     } catch (err) {
//       console.error("Upload failed:", err);
//       if (err.response) {
//         console.error('Error response:', err.response.data);
//         console.error('Error status:', err.response.status);
//         console.error('Error headers:', err.response.headers);
        
//         const errorMessage = err.response.data?.message || err.response.data || 'Failed to upload document';
//         toast.error(`Upload failed: ${errorMessage}`);
//       } else if (err.request) {
//         console.error('No response received:', err.request);
//         toast.error('No response from server. Please check your connection.');
//       } else {
//         console.error('Error setting up request:', err.message);
//         toast.error('Failed to upload document: ' + err.message);
//       }
//     }
//   };

//   const handleView = (base64String) => {
//     const blob = base64toBlob(base64String, "application/pdf");
//     const blobUrl = URL.createObjectURL(blob);
//     window.open(blobUrl, "_blank");
//   };

//   const base64toBlob = (base64, contentType) => {
//     const byteCharacters = atob(base64);
//     const byteNumbers = new Array(byteCharacters.length).fill().map((_, i) => byteCharacters.charCodeAt(i));
//     const byteArray = new Uint8Array(byteNumbers);
//     return new Blob([byteArray], { type: contentType });
//   };

//   const filteredPersonalDocs = personalDocs.filter(doc =>
//     doc.name.toLowerCase().includes(search.toLowerCase()) ||
//     doc.type.toLowerCase().includes(search.toLowerCase())
//   );

//   const filteredCompanyDocs = companyDocs.filter(doc =>
//     doc.name.toLowerCase().includes(search.toLowerCase()) ||
//     doc.type.toLowerCase().includes(search.toLowerCase())
//   );

//   // Show loading or error state if no employee ID
//   if (!isAuthenticated) {
//     return <div>Please login to access documents.</div>;
//   }

//   if (!employeeId) {
//     return <div>Loading employee information...</div>;
//   }

//   return (
//     <div className={styles.container}>
//       <div className={styles.mainContent}>
//         <header className={styles.header}>
//           Document Center - Employee ID: {employeeId}
//         </header>
//         <ToastContainer position="top-right" autoClose={3000} hideProgressBar />

//         <section className={styles.section}>
//           <h3>1. Personal Documents</h3>
//           <input
//             type="text"
//             placeholder="🔍 Search by name or type..."
//             value={search}
//             onChange={(e) => setSearch(e.target.value)}
//             className={styles.searchBar}
//           />

//           <table className={styles.table}>
//             <thead>
//               <tr>
//                 <th>Document</th>
//                 <th>Type</th>
//                 <th>File</th>
//                 <th>Uploaded On</th>
//                 <th>Status</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filteredPersonalDocs.map((doc, idx) => (
//                 <tr key={idx}>
//                   <td>{doc.name}</td>
//                   <td>{doc.type}</td>
//                   <td>{getFileIcon(doc.type)} {doc.type}</td>
//                   <td>{doc.date}</td>
//                   <td>
//                     <span className={`${styles.status} ${styles.approved}`}>Approved</span>
//                   </td>
//                   <td>
//                     <button
//                       className={styles.viewBtn}
//                       onClick={() => handleView(doc.base64Doc)}
//                     >
//                       👁 View
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>

//           <div className={styles.uploadSection}>
//             <div className={styles.uploadControls}>
//               <input type="file" onChange={handleFileChange} />
//               {uploadingFile && <span className={styles.previewText}>Selected: {uploadingFile.name}</span>}
//               <button onClick={handleUpload}>⬆ Upload Personal Document</button>
//             </div>
//           </div>
//         </section>

//         <section className={styles.section}>
//           <h3>2. Company Documents</h3>
//           <table className={styles.table}>
//             <thead>
//               <tr>
//                 <th>Document</th>
//                 <th>Type</th>
//                 <th>File</th>
//                 <th>Uploaded On</th>
//                 <th>Status</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filteredCompanyDocs.map((doc, idx) => (
//                 <tr key={idx}>
//                   <td>{doc.name}</td>
//                   <td>{doc.type}</td>
//                   <td>{getFileIcon(doc.type)} {doc.type}</td>
//                   <td>{doc.date}</td>
//                   <td>
//                     <span className={`${styles.status} ${styles.approved}`}>Approved</span>
//                   </td>
//                   <td>
//                     <button
//                       className={styles.viewBtn}
//                       onClick={() => handleView(doc.base64Doc)}
//                     >
//                       👁 View
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </section>
//         <footer className="footer">
//         <div className="footerLeft">
//           Copyright © 2025 Kodvix Technologies. All Rights Reserved.
//         </div>
//         <div className="footer-right">
//           <a
//             href="https://www.kodvix.com/"
//             target="_blank"
//             rel="noopener noreferrer"
//           >
//             Kodvix Technologies
//           </a>
//         </div>
//       </footer>
//       </div>
      
      
//     </div>
//   );
// };

// export default DocumentCenter;
