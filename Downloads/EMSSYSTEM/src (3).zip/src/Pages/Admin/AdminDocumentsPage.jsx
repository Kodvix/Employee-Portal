import React, { useState, useEffect } from 'react';
import styles from './AdminDocumentsPage.module.css';
import axios from 'axios';
import { FaFilePdf, FaFileWord, FaFileImage } from 'react-icons/fa';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useAuth } from '../../context/AuthContext';

const API_BASE_URL = 'http://localhost:8080/api';

const AdminDocumentsPage = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [companyDocs, setCompanyDocs] = useState([]);
  const [personalDocs, setPersonalDocs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [uploadFiles, setUploadFiles] = useState({});
  const { isAuthenticated } = useAuth();

  // Fetch all employees on component mount
  useEffect(() => {
    if (!isAuthenticated) {
      toast.error('Please login to access this page');
      return;
    }
    fetchEmployees();
  }, [isAuthenticated]);

  // Fetch documents when employee is selected
  useEffect(() => {
    if (selectedEmployee) {
      fetchEmployeeDocuments(selectedEmployee);
    }
  }, [selectedEmployee]);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE_URL}/employee`);
      setEmployees(response.data);
      if (response.data.length > 0) {
        setSelectedEmployee(response.data[0].id);
      }
    } catch (err) {
      console.error('Error fetching employees:', err);
      toast.error('Failed to fetch employees');
    } finally {
      setLoading(false);
    }
  };

  const fetchEmployeeDocuments = async (employeeId) => {
    try {
      setLoading(true);
      // Fetch company documents
      const companyResponse = await axios.get(`${API_BASE_URL}/employee-images/emp/${employeeId}`);
      setCompanyDocs(companyResponse.data);

      // Fetch personal documents
      const personalResponse = await axios.get(`${API_BASE_URL}/documents/employee/${employeeId}`);
      setPersonalDocs(personalResponse.data);
    } catch (err) {
      console.error('Error fetching documents:', err);
      toast.error('Failed to fetch documents');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e, docType) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('File size must be less than 10MB');
      return;
    }

    // Validate file type
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Please upload PDF, JPEG, or PNG files only');
      return;
    }

    setUploadFiles(prev => ({ ...prev, [docType]: file }));
};

  const handleCompanyDocUpload = async (docType) => {
  const file = uploadFiles[docType];
    if (!file || !selectedEmployee) {
      toast.error('Please select a file and employee');
      return;
    }

  try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('empId', selectedEmployee);
      formData.append('docType', docType);

      const response = await axios.post(`${API_BASE_URL}/employee-images`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
      }
      });

      if (response.data) {
    toast.success(`${docType} uploaded successfully!`);
    setUploadFiles(prev => ({ ...prev, [docType]: null }));
        fetchEmployeeDocuments(selectedEmployee);
      }
  } catch (err) {
      console.error('Upload failed:', err);
      toast.error(`Failed to upload ${docType}: ${err.response?.data?.message || err.message}`);
  }
};

  const handlePersonalDocUpload = async (file) => {
    if (!file || !selectedEmployee) {
      toast.error('Please select a file and employee');
      return;
    }

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('employeeId', selectedEmployee);

      const response = await axios.post(`${API_BASE_URL}/documents/upload/${selectedEmployee}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      if (response.data) {
        toast.success('Personal document uploaded successfully!');
        setUploadFiles(prev => ({ ...prev, personalDoc: null }));
        fetchEmployeeDocuments(selectedEmployee);
      }
    } catch (err) {
      console.error('Upload failed:', err);
      toast.error(`Failed to upload personal document: ${err.response?.data?.message || err.message}`);
    }
  };

  const handleDeleteCompanyDoc = async (docId) => {
    try {
      await axios.delete(`${API_BASE_URL}/employee-images/${docId}`);
      toast.success('Company document deleted successfully!');
      fetchEmployeeDocuments(selectedEmployee);
    } catch (err) {
      console.error('Delete failed:', err);
      toast.error('Failed to delete company document');
    }
  };

  const handleDeletePersonalDoc = async (docId) => {
    try {
      await axios.delete(`${API_BASE_URL}/documents/employee/${selectedEmployee}/document/${docId}`);
      toast.success('Personal document deleted successfully!');
      fetchEmployeeDocuments(selectedEmployee);
    } catch (err) {
      console.error('Delete failed:', err);
      toast.error('Failed to delete personal document');
    }
  };

  const getEmployeeName = (empId) => {
    if (!empId) return 'Unknown Employee';
    const employee = employees.find(emp => emp.id === parseInt(empId));
    return employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown Employee';
  };

  const handleViewDocument = async (doc, type) => {
    try {
      let base64Data;
      if (type === 'company') {
        base64Data = doc.offerLetterDoc || doc.latestPaySlipDoc || doc.doc;
      } else {
        base64Data = doc.data;
      }

      if (!base64Data) {
        toast.error('Document data not found');
        return;
      }

      // Create blob from base64
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      
      // Create URL and open in new tab
      const url = URL.createObjectURL(blob);
      const newWindow = window.open(url, '_blank');
      
      if (!newWindow) {
        toast.error('Please allow pop-ups to view documents');
      }
    } catch (error) {
      console.error('Error viewing document:', error);
      toast.error('Failed to open document. Please try again.');
    }
  };

  if (loading) return <div className={styles.loading}>Loading...</div>;
  if (error) return <div className={styles.error}>{error}</div>;

  return (
    <div className={styles.container}>
      <div className={styles.main}>
          <header className={styles.header}>
            <h2>📁 Admin Document Center</h2>
          </header>

        <div className={styles.employeeSelector}>
          <label>Select Employee:</label>
            <select
            value={selectedEmployee || ''} 
            onChange={(e) => setSelectedEmployee(e.target.value)}
            >
            {employees.map(emp => (
              <option key={emp.id} value={emp.id}>
                {emp.firstName} {emp.lastName} (ID: {emp.id})
              </option>
            ))}
            </select>
        </div>

        {selectedEmployee && (
          <>
            {/* Company Documents Section */}
            <section className={styles.section}>
              <h3>Company Documents</h3>
<div className={styles.uploadSection}>
  <div className={styles.uploadControls}>
    <label>📄 Upload Offer Letter:</label>
                  <input 
                    type="file" 
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => handleFileChange(e, 'offerLetterDoc')} 
                  />
                  {uploadFiles.offerLetterDoc && (
                    <span className={styles.fileName}>Selected: {uploadFiles.offerLetterDoc.name}</span>
                  )}
                  <button 
                    onClick={() => handleCompanyDocUpload('offerLetterDoc')}
                    disabled={!uploadFiles.offerLetterDoc}
                  >
                    Upload
                  </button>
  </div>

  <div className={styles.uploadControls}>
    <label>📄 Upload Latest Payslip:</label>
                  <input 
                    type="file" 
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => handleFileChange(e, 'latestPaySlipDoc')} 
                  />
                  {uploadFiles.latestPaySlipDoc && (
                    <span className={styles.fileName}>Selected: {uploadFiles.latestPaySlipDoc.name}</span>
                  )}
                  <button 
                    onClick={() => handleCompanyDocUpload('latestPaySlipDoc')}
                    disabled={!uploadFiles.latestPaySlipDoc}
                  >
                    Upload
                  </button>
  </div>

  <div className={styles.uploadControls}>
    <label>📄 Upload Additional Document:</label>
                  <input 
                    type="file" 
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => handleFileChange(e, 'doc')} 
                  />
                  {uploadFiles.doc && (
                    <span className={styles.fileName}>Selected: {uploadFiles.doc.name}</span>
                  )}
                  <button 
                    onClick={() => handleCompanyDocUpload('doc')}
                    disabled={!uploadFiles.doc}
                  >
                    Upload
                  </button>
  </div>
</div>

              <div className={styles.documentsGrid}>
                {companyDocs.map((doc, index) => (
                  <div key={`company-${doc.id}-${index}`} className={styles.documentCard}>
                    <div className={styles.documentIcon}>
                      <FaFilePdf />
                    </div>
                    <div className={styles.documentInfo}>
                      <h4>{doc.offerLetterDoc ? 'Offer Letter' : 
                           doc.latestPaySlipDoc ? 'Latest Payslip' : 
                           'Additional Document'}</h4>
                      <p>Type: PDF</p>
                      <p>Employee: {getEmployeeName(selectedEmployee)}</p>
                      <p>Uploaded: {new Date().toLocaleDateString()}</p>
                    </div>
                    <div className={styles.documentActions}>
                      <button onClick={() => handleViewDocument(doc, 'company')}>
                        👁 View
                      </button>
                      <button onClick={() => handleDeleteCompanyDoc(doc.id)}>
                        🗑 Delete
                      </button>
                    </div>
                  </div>
                ))}
            </div>
            </section>

            {/* Personal Documents Section */}
            <section className={styles.section}>
              <h3>Personal Documents</h3>
              <div className={styles.uploadSection}>
                <div className={styles.uploadControls}>
                  <label>📄 Upload Personal Document:</label>
                  <input 
                    type="file" 
                    onChange={(e) => handleFileChange(e, 'personalDoc')} 
                  />
                  <button onClick={() => handlePersonalDocUpload(uploadFiles.personalDoc)}>
                    Upload
                  </button>
          </div>
          </div>

              <div className={styles.documentsGrid}>
                {personalDocs.map((doc, index) => (
                  <div key={`personal-${doc.id}-${index}`} className={styles.documentCard}>
                    <div className={styles.documentIcon}>
                      <FaFilePdf />
                    </div>
                    <div className={styles.documentInfo}>
                      <h4>{doc.name}</h4>
                      <p>Type: {doc.type}</p>
                      <p>Employee: {getEmployeeName(selectedEmployee)}</p>
                      <p>Uploaded: {new Date(doc.uploadDate).toLocaleDateString()}</p>
                    </div>
                    <div className={styles.documentActions}>
                      <button onClick={() => handleViewDocument(doc, 'personal')}>
                        👁 View
                      </button>
                      <button onClick={() => handleDeletePersonalDoc(doc.id)}>
                        🗑 Delete
                        </button>
                    </div>
                  </div>
                  ))}
          </div>
            </section>
        </>
      )}
     <footer className={styles.footer}>
        <div className={styles.footerLeft}>
        Copyright © 2025 Kodvix Technologies. All Rights Reserved.
      </div>
    <div className={styles.footerright}>
        <a
          href="https://www.kodvix.com/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Kodvix Technologies
        </a>
      </div>
    </footer>
      </div>
      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
     
    </div>
  );
};

export default AdminDocumentsPage;

